# YouTube Together Example
YouTube Together Example Bot

# Kütüphane
**[discord.js](https://discord.js.org)**

# Bot
**[Click here to invite](https://discord.com/api/oauth2/authorize?client_id=674970405865390092&permissions=3073&scope=bot)**

# Installing
- İndirin
- Değiştirin `.env.example` to `.env`
- Token Ekleyin `.env` :: `DISCORD_TOKEN=YOUR_BOT_TOKEN`
- Başlatın `npm start`

# YouTube Together
- baştat `a!yttogether <channelid>`
- odaya katılan bot ile keyfini çıkarın

# Default command prefix
`a!`